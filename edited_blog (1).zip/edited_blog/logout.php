<?php
   session_start();
   session_destroy();
?>

<!DOCTYPE html>
<html>
    <h3>You are logged out</h3>
    <body>
    <a href="index.php">Home Page</a> | <a href="login.php">Login</a>
    </body>
</html>
